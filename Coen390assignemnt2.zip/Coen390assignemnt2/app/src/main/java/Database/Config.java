package Database;

import java.util.Date;

public class Config {
    public static final String DATABASE_NAME ="student-db";
    public static final int DATABASE_VERSION = 1;

    public static final String PROFILE_TABLE_NAME = "profile";
    public static final String COLUMN_PROFILE_ID = "id";
    public static final String COLUMN_SURNAME = "surname";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_PROFILE_GPA = "gpa";
    public static final String COLUMN_PROFILE_CREATION_DATE = "creation_date";

    public static final String ACCESS_TABLE_NAME = "access";
    public static final String COLUMN_ACCESS_ID = "acc_id";
    public static final String COLUMN_ACCESS_PROFILE_ID = "profile_id";
    public static final String COLUMN_ACCESS_TYPE = "type";
    public static final String COLUMN_ACCESS_TIMESTAMP = "access_timestamp";

}
