package Database;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.example.coen390assignemnt2.Access;
import com.example.coen390assignemnt2.Profile;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Date;

public class DatabaseHelper extends SQLiteOpenHelper {

    private Context context;
    private static final String TAG = "DatabaseHelper";
    public DatabaseHelper(Context context)
    {
        super(context,Config.DATABASE_NAME,null,Config.DATABASE_VERSION);
        this.context = context;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_TABLE_PROFILE = "CREATE TABLE " + Config.PROFILE_TABLE_NAME +
                "(" + Config.COLUMN_PROFILE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + Config.COLUMN_SURNAME + " TEXT NOT NULL,"
                + Config.COLUMN_NAME + " TEXT NOT NULL,"
                + Config.COLUMN_PROFILE_GPA + " TEXT NOT NULL,"
                +Config.COLUMN_PROFILE_CREATION_DATE + " TEXT NOT NULL)";
        Log.d(TAG,CREATE_TABLE_PROFILE);

        sqLiteDatabase.execSQL(CREATE_TABLE_PROFILE);

        String CREATE_TABLE_ACCESS = "CREATE TABLE " + Config.ACCESS_TABLE_NAME +
                "(" + Config.COLUMN_ACCESS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + Config.COLUMN_ACCESS_PROFILE_ID + " INTEGER NOT NULL,"
                + Config.COLUMN_ACCESS_TYPE + " TEXT NOT NULL,"
                + Config.COLUMN_ACCESS_TIMESTAMP + " TEXT NOT NULL)";
        Log.d(TAG,CREATE_TABLE_ACCESS);

        sqLiteDatabase.execSQL(CREATE_TABLE_ACCESS);

        Log.d(TAG,"db created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public long insertProfile(Profile profile)
    {
        long tableID = -1;
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(Config.COLUMN_PROFILE_ID, profile.getPROFILE_ID());
        contentValues.put(Config.COLUMN_SURNAME, profile.getSURNAME());
        contentValues.put(Config.COLUMN_NAME, profile.getNAME());
        contentValues.put(Config.COLUMN_PROFILE_GPA, profile.getGPA());
        contentValues.put(Config.COLUMN_PROFILE_CREATION_DATE, profile.getCREATION_DATE());

        try
        {
            tableID = db.insertOrThrow(Config.PROFILE_TABLE_NAME, null, contentValues);
        }
        catch (SQLException e)
        {
            Log.d(TAG,"EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally {
            db.close();
        }
        insertAccess(new Access(profile.getPROFILE_ID(), "Created"));
        return tableID;
    }

    public List<Profile> getAllProfiles()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try
        {
            cursor = db.query(Config.PROFILE_TABLE_NAME, null, null,null,null, null, null);
            if(cursor != null)
            {
                if(cursor.moveToFirst())
                {
                    List<Profile> profiles = new ArrayList<>();
                    Log.d(TAG,"Column" +cursor.getColumnIndex(Config.COLUMN_PROFILE_ID));
                    do {
                        int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_PROFILE_ID));
                        String surname = cursor.getString(cursor.getColumnIndex(Config.COLUMN_SURNAME));
                        String name = cursor.getString(cursor.getColumnIndex(Config.COLUMN_NAME));
                        float gpa = cursor.getFloat(cursor.getColumnIndex(Config.COLUMN_PROFILE_GPA)); //change made
                        String date = cursor.getString(cursor.getColumnIndex(Config.COLUMN_PROFILE_CREATION_DATE));

                        profiles.add(new Profile(id, surname, name, gpa));

                    }while (cursor.moveToNext());
                    return profiles;
                }
            }
        }
        catch (SQLException e)
        {
            Log.d(TAG,"EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally {
            if(cursor != null)
                cursor.close();

            db.close();
        }
        return Collections.emptyList();

    }

    public Profile getProfileByID (int profileID)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM " + Config.PROFILE_TABLE_NAME + " WHERE " + Config.COLUMN_PROFILE_ID + "  =  " + profileID, null);
            if (cursor != null) {
                if (cursor.moveToFirst())
                {
                    int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_PROFILE_ID));
                    String surname = cursor.getString(cursor.getColumnIndex(Config.COLUMN_SURNAME));
                    String name = cursor.getString(cursor.getColumnIndex(Config.COLUMN_NAME));
                    float gpa = cursor.getFloat(cursor.getColumnIndex(Config.COLUMN_PROFILE_GPA)); //change made
                    String date = cursor.getString(cursor.getColumnIndex(Config.COLUMN_PROFILE_CREATION_DATE));
                    return new Profile(id, surname, name, gpa, date);

                }
            }
        }

        catch(SQLException e)
        {
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally{
            if (cursor != null)
                cursor.close();

                db.close();
            }
        return null;
        }

    public List<Access> getAccessByID (int profileID)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT * FROM " + Config.ACCESS_TABLE_NAME + " WHERE " + Config.COLUMN_ACCESS_PROFILE_ID + "  =  " + profileID, null);
            if (cursor != null) {
                if (cursor.moveToFirst())
                {
                    List<Access> accesses = new ArrayList<>();
                    Log.d(TAG,"Column" +cursor.getColumnIndex(Config.COLUMN_ACCESS_ID));
                    do {
                        int id = cursor.getInt(cursor.getColumnIndex(Config.COLUMN_ACCESS_ID));
                        String type = cursor.getString(cursor.getColumnIndex(Config.COLUMN_ACCESS_TYPE));
                        String time = cursor.getString(cursor.getColumnIndex(Config.COLUMN_ACCESS_TIMESTAMP));

                        accesses.add(new Access(id, profileID , type, time));

                    }while (cursor.moveToNext());
                    return accesses;
                }
            }
        }

        catch(SQLException e)
        {
            Log.d(TAG, "EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally{
            if (cursor != null)
                cursor.close();

            db.close();
        }
        return null;
    }

    public long insertAccess(Access access)
    {
        long tableID = -1;
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(Config.COLUMN_ACCESS_ID, access.getACCESS_ID());
        contentValues.put(Config.COLUMN_ACCESS_PROFILE_ID, access.getACCESS_PROFILE_ID());
        contentValues.put(Config.COLUMN_ACCESS_TYPE, access.getACCESS_TYPE());
        contentValues.put(Config.COLUMN_ACCESS_TIMESTAMP, access.getACCESS_TIME());

        try
        {
            tableID = db.insertOrThrow(Config.ACCESS_TABLE_NAME, null, contentValues);
        }
        catch (SQLException e)
        {
            Log.d(TAG,"EXCEPTION: " + e);
            Toast.makeText(context, "Operation Failed!: " + e, Toast.LENGTH_LONG).show();
        }
        finally {
            db.close();
            Log.d(TAG,"Created");
        }
        return tableID;
    }
}
