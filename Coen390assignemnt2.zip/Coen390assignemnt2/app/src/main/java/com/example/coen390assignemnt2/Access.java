package com.example.coen390assignemnt2;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Access {
    private Integer ACCESS_ID;
    private String ACCESS_TYPE;
    private Integer ACCESS_PROFILE_ID;
    private String ACCESS_TIME;

    public Access(Integer ACCESS_ID, Integer ACCESS_PROFILE_ID, String ACCESS_TYPE, String ACCESS_TIME) { //change made
        this.ACCESS_ID = ACCESS_ID;
        this.ACCESS_TYPE = ACCESS_TYPE;
        this.ACCESS_PROFILE_ID = ACCESS_PROFILE_ID;
        this.ACCESS_TIME = ACCESS_TIME;
    }

    public Access(Integer ACCESS_PROFILE_ID, String ACCESS_TYPE) { //change made
        this.ACCESS_TYPE = ACCESS_TYPE;
        this.ACCESS_PROFILE_ID = ACCESS_PROFILE_ID;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd @ HH:mm:ss");
        String ACCESS_TIME = sdf.format(new Date());
        setACCESS_TIME(ACCESS_TIME);
    }

    public Integer getACCESS_ID() {
        return ACCESS_ID;
    }

    public void setACCESS_ID(Integer ACCESS_ID) {
        this.ACCESS_ID = ACCESS_ID;
    }

    public String getACCESS_TYPE() {
        return ACCESS_TYPE;
    }

    public void setACCESS_TYPE(String ACCESS_TYPE) {
        this.ACCESS_TYPE = ACCESS_TYPE;
    }

    public String getACCESS_TIME() {
        return ACCESS_TIME;
    }

    public void setACCESS_TIME(String ACCESS_TIME) {
        this.ACCESS_TIME = ACCESS_TIME;
    }

    public Integer getACCESS_PROFILE_ID() {
        return ACCESS_PROFILE_ID;
    }

    public void setACCESS_PROFILE_ID(Integer ACCESS_PROFILE_ID) {
        this.ACCESS_PROFILE_ID = ACCESS_PROFILE_ID;
    }
}
