package com.example.coen390assignemnt2;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Date;

import Database.DatabaseHelper;

public class InsertProfileDialogueFragment extends DialogFragment {

    protected EditText surnameEditText;
    protected EditText nameEditText;
    protected EditText iDEditText;
    protected EditText gPAEditText;
    protected Button saveProfileButton;
    protected Button cancelProfileButton;
    private Context context;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_insert_profile,container,false);
        surnameEditText = view.findViewById(R.id.surnameEditText);
        nameEditText = view.findViewById(R.id.nameEditText);
        iDEditText = view.findViewById(R.id.iDEditText);
        gPAEditText = view.findViewById(R.id.gPAEditText);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        saveProfileButton = view.findViewById(R.id.saveProfileButton);
        cancelProfileButton = view.findViewById(R.id.cancelProfileButton);

        saveProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String surname = surnameEditText.getText().toString();
                String name = nameEditText.getText().toString();
                Integer id;
                Float gpa;
                try {
                     id = Integer.parseInt(iDEditText.getText().toString());
                     gpa = Float.parseFloat(gPAEditText.getText().toString()); //change made
                }
                catch (Exception e)
                {
                    Toast.makeText(getActivity(), "Operation Failed, missing or empty ID or GPA" ,Toast.LENGTH_LONG).show();
                    return;
                }

                String date = sdf.format(new Date());

                DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
                if(!(surname.equals("") || name.equals("") || id.equals("") || gpa.equals("") ||gpa < 0 || gpa > 4.3 || id < 10000000 || id > 99999999))
                {
                    dbHelper.insertProfile(new Profile(id, surname, name, gpa));
                    ((MainActivity)getActivity()).loadListView();
                    getDialog().dismiss();
                }
                else
                {
                    Toast.makeText(getActivity(), "Operation Failed, missing or empty strings" ,Toast.LENGTH_LONG).show();
                }
            }
        });

        cancelProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                getDialog().dismiss();
            }
        });


        return view;
    }
}
