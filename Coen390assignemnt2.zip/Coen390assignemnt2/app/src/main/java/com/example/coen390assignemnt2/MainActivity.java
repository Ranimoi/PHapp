package com.example.coen390assignemnt2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import Database.DatabaseHelper;

public class MainActivity extends AppCompatActivity {

    protected ListView profileListView;
    protected FloatingActionButton addStudentFloatingButton;
    protected TextView numberOfProfiles;
    private static final String TAG = "DatabaseHelper";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        numberOfProfiles = (TextView) findViewById(R.id.numberOfProfiles);
        profileListView = findViewById(R.id.profileListView);
        addStudentFloatingButton = findViewById(R.id.addStudentFloatingButton);
        loadListView();

        addStudentFloatingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               InsertProfileDialogueFragment dialog = new InsertProfileDialogueFragment();
               dialog.show(getSupportFragmentManager(),"InsertProfileFragment");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.activity_main);
        numberOfProfiles = (TextView) findViewById(R.id.numberOfProfiles);
        profileListView = findViewById(R.id.profileListView);
        addStudentFloatingButton = findViewById(R.id.addStudentFloatingButton);
        loadListView();

        addStudentFloatingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InsertProfileDialogueFragment dialog = new InsertProfileDialogueFragment();
                dialog.show(getSupportFragmentManager(), "InsertProfileFragment");
            }
        });
    }

    protected void loadListView()
    {
       DatabaseHelper dbHelper = new DatabaseHelper(this);
        List<Profile> profiles = dbHelper.getAllProfiles();

       numberOfProfiles.setText(profiles.size() + " Profiles");

        ArrayList<String> profilesListText = new ArrayList<>();

        for(int i=0; i<profiles.size(); i++)
        {
            String temp ="";
            temp+= profiles.get(i).getSURNAME() + ", " + profiles.get(i).getNAME();

            profilesListText.add(temp);
        }
       ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,profilesListText);
        profileListView.setAdapter(arrayAdapter);

        profileListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
                Bundle b = new Bundle();
                b.putInt("key", profiles.get(i).getPROFILE_ID());
                intent.putExtras(b);
                startActivity(intent);
                finish();
            }
        });

    }
}