package com.example.coen390assignemnt2;
import java.util.Date;
import java.text.SimpleDateFormat;

public class Profile {
    private Integer PROFILE_ID;
    private String SURNAME;
    private String NAME;
    private Float GPA; //change made
    private String CREATION_DATE;

    public Profile(Integer PROFILE_ID, String SURNAME, String NAME, Float GPA, String CREATION_DATE) { //change made
        this.PROFILE_ID = PROFILE_ID;
        this.SURNAME = SURNAME;
        this.NAME = NAME;
        this.GPA = GPA;
        this.CREATION_DATE = CREATION_DATE;
    }

    public Profile(Integer PROFILE_ID, String SURNAME, String NAME, Float GPA) { //change made
        this.PROFILE_ID = PROFILE_ID;
        this.SURNAME = SURNAME;
        this.NAME = NAME;
        this.GPA = GPA;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd @ HH:mm:ss");
        String CREATION_DATE = sdf.format(new Date());
        setCREATION_DATE(CREATION_DATE);
    }

    public Profile(String SURNAME, String NAME, Float GPA) { //change made
        this.SURNAME = SURNAME;
        this.NAME = NAME;
        this.GPA = GPA;
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd @ HH:mm:ss");
        String CREATION_DATE = sdf.format(new Date());
        setCREATION_DATE(CREATION_DATE);
    }

    public Integer getPROFILE_ID() {
        return PROFILE_ID;
    }

    public String getSURNAME() {
        return SURNAME;
    }

    public String getNAME() {
        return NAME;
    }

    public Float getGPA() {
        return GPA;
    } //change made

    public String getCREATION_DATE() {

        return CREATION_DATE;
    }

    public void setPROFILE_ID(Integer PROFILE_ID) {
        this.PROFILE_ID = PROFILE_ID;
    }

    public void setSURNAME(String SURNAME) {
        this.SURNAME = SURNAME;
    }

    public void setNAME(String NAME) {
        this.NAME = NAME;
    }

    public void setGPA(Float GPA) {
        this.GPA = GPA;
    } //change made

    public void setCREATION_DATE(String CREATION_DATE) {
        this.CREATION_DATE = CREATION_DATE;
    }
}
