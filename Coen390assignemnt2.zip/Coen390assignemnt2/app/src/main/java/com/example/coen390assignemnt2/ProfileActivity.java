package com.example.coen390assignemnt2;

import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

import Database.DatabaseHelper;

public class ProfileActivity extends MainActivity{
protected TextView surnameTextView;
protected TextView nameTextView;
protected TextView iDTextView;
protected TextView gPATextView;
protected TextView dateTextView;
private static final String TAG = "DatabaseHelper";
protected ListView accessListView;
protected TextView singleAccess;
protected Integer id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_activity);

        Bundle b = getIntent().getExtras();
        int value = -1;
        if(b != null)
            value = b.getInt("key");

        this.id = value;

        Log.d(TAG,"ID:" + value);
        loadProfile(value);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.insertAccess(new Access(value, "Opened"));

        accessListView = findViewById(R.id.aListView);
        loadListView();

    }


    @Override
    protected void onResume() {
        super.onResume();
        setContentView(R.layout.profile_activity);
        Bundle b = getIntent().getExtras();
        int value = -1;
        if (b != null)
            value = b.getInt("key");

        Log.d(TAG, "ID:" + value);
        loadProfile(value);
        loadListView(value);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        dbHelper.insertAccess(new Access(id, "Closed"));

    }

    public void loadProfile(int value)
    {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
       Profile profiles = dbHelper.getProfileByID(value);

        surnameTextView= (TextView) findViewById(R.id.surnameTextView);
        String surname ="";
        surname+= "Surname: " + profiles.getSURNAME();
        surnameTextView.setText(surname);

        nameTextView= (TextView) findViewById(R.id.nameTextView);
        String name ="";
        name+= "Name: " + profiles.getNAME();
        nameTextView.setText(name);

        iDTextView= (TextView) findViewById(R.id.iDTextView);
        String idName ="";
        idName+= "ID: " + String.valueOf(profiles.getPROFILE_ID());
        iDTextView.setText((idName));

        gPATextView= (TextView) findViewById(R.id.gPATextView);
        String gpa ="";
        gpa+= "GPA: " + String.valueOf(profiles.getGPA());
        gPATextView.setText(gpa);

        dateTextView= (TextView) findViewById(R.id.dateTextView);
        String date ="";
        date+= "Profile Created: " + profiles.getCREATION_DATE();
        dateTextView.setText(date);
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            moveTaskToBack(true);
        }
        return super.onKeyDown(keyCode, event);
    }



    protected void loadListView(int profileID)
    {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        List<Access> accesses = dbHelper.getAccessByID(profileID);
        Log.d(TAG,"Accesses " + accesses.get(0).getACCESS_PROFILE_ID());



        ArrayList<String> accessesListText = new ArrayList<>();

        for(int i=0; i<accesses.size(); i++)
        {
            String temp ="";
            temp+= accesses.get(i).getACCESS_TIME() + " " + accesses.get(i).getACCESS_TYPE();

            accessesListText.add(temp);
        }
        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,accessesListText);
        accessListView = findViewById(R.id.aListView);
        accessListView.setAdapter(arrayAdapter);

    }

}
